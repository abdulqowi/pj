package com.fp.TransService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransServiceApplication.class, args);
	}

}
