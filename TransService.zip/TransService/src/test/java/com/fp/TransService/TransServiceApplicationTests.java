package com.fp.TransService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
